XQMode v0.1 alpha for Processing - ReadMe
----------------------------------------------------------------------------------------------------------------------------------

XQMode requires Processing 2.0a6 or later. Java version 1.6 Update 30 and upwards is recommended. XQMode 
will need some modifications to your Processing app in order to run. It�s suggested that you make a backup 
of your Processing app before proceeding further.

----------------------------------------------------------------------------------------------------------------------------------
Installation steps:

Windows

1. Create a backup/copy of your Processing folder,i.e, the folder where processing.exe is located.
2. Copy xqmodeData into the Processing folder,i.e, the folder where processing.exe is located.
3. Open the xqmodeData folder. Double-click on Modify_Processing_Windows.bat.
If you get access denied errors, rename your default processing.exe to processing_original.exe and then copy the 
processing.exe located inside xqmodeData to the Processing folder. The script tries to do this automatically, 
but the processing folder is usually read only.
4. Now copy the XQMode folder located inside xqmodeData to <Your Processing Sketchbook>/modes folder. Create a folder 
named 'modes' if there isn�t one.
5. Run Processing. Switch to XQMode.

----------------------------------------------------------------------------------------------------------------------------------
Mac OS X

1. Create a backup/copy of your Processing.app
2. Copy xqmodeData into Processing.app's parent folder, i.e, the folder inside which Processing.app is located.
3. Open the xqmodeData folder. Double-click on Modify_Processing_MacOSX.command.
4. Now copy the XQMode folder located inside xqmodeData to <Your Processing Sketchbook>/modes folder. Create a folder 
named 'modes' if there isn�t one.
5. Run Processing. Switch to XQMode.

----------------------------------------------------------------------------------------------------------------------------------
Linux

1. Create a backup/copy of your Processing folder
2. Copy xqmodeData into Processing folder, i.e, the folder inside which Processing app is located.
3. Open the terminal and navigate to xqmodeData folder. Run ./Modify_Processing_Linux.sh
4. Now copy the XQMode located inside xqmodeData folder to <Your Processing Sketchbook>/modes folder. Create a folder 
named 'modes' if there isn�t one.
5. Run Processing. Switch to XQMode.

----------------------------------------------------------------------------------------------------------------------------------
What these scripts do is copy the additional jar files into the lib folder and then update the classpath of processing
app. On Windows, this requires building a new .exe so you need to replace your processing.exe with the custom built one. 

On Mac OS X, editing the classpath involves editing the Info.plist file of the app. The original Info.plist file is 
renamed and is replaced by a modified Info.plist file. 

Linux systems don't need any extra changes other than copying the jar files.

----------------------------------------------------------------------------------------------------------------------------------
If you've any questions, bugs or problems, please comment in the processing forum thread or head over to XQMode's github repo.

XQMode's git repo: www.github.com/Manindra29/XQMode

Manindra Moharana (www.quarkninja.blogspot.com)
Daniel Shiffman (www.shiffman.net)

2nd June, 2012
